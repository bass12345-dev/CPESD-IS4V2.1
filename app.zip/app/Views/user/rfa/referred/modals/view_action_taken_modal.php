<div class="modal fade" id="view_action_taken_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">View Action</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <input type="hidden" name="t_id">
            <div id="action_taken" class="p-4">
               <p>Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. Modal body text goes here. vModal body text goes here.Modal body text goes here. Modal body text goes here.Modal body text goes here.Modal body text goes here. Modal body text goes here.</p>
            </div>
         </div>
         
      </div>
   </div>
</div>