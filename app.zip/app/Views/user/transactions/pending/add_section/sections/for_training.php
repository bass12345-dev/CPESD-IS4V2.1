<div class="for_training" hidden >
	<h5>For Training</h5>
	<div class="form-group">
		<div class="col-12">Title of Training</div>
		<input type="text" class="form-control input" name="title_of_training" placeholder="">
		<div class="wizard-form-error"></div>
	</div>
	<div class="row">
		<div class=" col-md-6">
			<div class="form-group">
				<div class="col-12">Number_of_participants</div>
				<input type="number" class="form-control wizard-required input" name="number_of_participants">
				<div class="wizard-form-error"></div>
			</div>
		</div>
		<div class=" col-md-6 ">
			<div class="form-group">
				<div class="col-12">Female</div>
				<input type="number" class="form-control wizard-required input" name="female">
				<div class="wizard-form-error"></div>
			</div>
		</div>
	</div>
	<div class="form-group">
		<div class="col-12">Over-all Ratings</div>
		<input type="text" class="form-control input" name="over_all_ratings" placeholder="">
		<div class="wizard-form-error"></div>
	</div>
	<div class="form-group">
		<div class="col-12">Name of Trainor</div>
		<input type="text" class="form-control input" name="name_of_trainor" placeholder="">
		<div class="wizard-form-error"></div>
	</div>
</div>