<div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left"><?php echo $title ?></h4>
                        <ul class="breadcrumbs pull-left">
                           <li><a href="<?php echo base_url() ?>user/dashboard">Home</a></li>
                           <li><a href="<?php echo base_url() ?>user/pending-transactions">Pending Transactions</a></li>
                           <li><a href="">Update Transaction</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>