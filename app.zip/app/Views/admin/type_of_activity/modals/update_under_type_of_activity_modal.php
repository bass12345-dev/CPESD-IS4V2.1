<div class="modal fade" id="update_under_type_of_activity_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
   <div class="modal-dialog modal-dialog-centered "  role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Update</h5>
            &nbsp;
            <h5 class="modal-title type_of_training_title" ></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               
               <div class="col-md-12">
                  <div class="card">
                     
                     <form id="update_under_type_of_activity_form">
                        <input  type="hidden" class="form-control"  name="under_activity_id"  placeholder="" required>
                          <input  type="hidden" class="form-control"  name="activ_id"  placeholder="" required>
                        <div class="form-group">
                          
                          
                           <input  type="text" class="form-control input" name="under_update_type_of_activity"  placeholder="" >      
                        </div>
                        <button  type="submit" class="btn sub-button mt-1 pr-4 pl-4 btn-update-under-activity pull-right"> Submit</button>
                        <div class="alert-add-under-activity"></div>
                        <!--  -->
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>