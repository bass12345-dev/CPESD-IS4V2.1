<div class="col-md-6">
   <div class="card">
      <h4 class="header-title">Add <?php echo $title;?></h4>
      <form id="add_responsible_section_form">
         <div class="form-group">
            <div class="col-12">Responsible Section<span class="text-danger">*</span></div>
            <input  type="text" class="form-control input" id="responsible_section" name="responsible_section"  placeholder="" required>      
         </div>
         <button  type="submit" class="btn  mt-1 pr-4 pl-4 btn-add-responsible sub-button" > Submit</button>
         <div class="alert"></div>
         <!--  -->
      </form>
   </div>
</div>